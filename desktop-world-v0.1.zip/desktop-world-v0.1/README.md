# Desktop World v0.1 — 研究与设计交付包

本目录是一份实现前设计，不是可运行的桌面自动化库。

## 文件

- `SPEC.md`：完整 RFC，包括领域模型、平台设计、执行与不确定性、安全、MVP、测试、POC、完整例子和原始来源。
- `api.go`：根包公共类型与接口草案。可编译，不包含 engine、原生 backend、constructor 或 wire codec。
- `examples/protocol/`：从 RFC 提取的 JSON 示例。`fragment-*.json` 为局部数据片段，不是独立请求。
- `verify_examples.py`：只进行 JSON 语法与若干示例内部一致性检查，不是完整协议实现或 native 测试。
- `go.mod`：使用刻意无效的占位 module path `example.invalid/desktopworld`；创建项目时替换。

## 已执行的检查

在 Linux/amd64 的 Go 1.23.2 环境中执行 `gofmt` 与 `go test ./...`，类型声明编译通过，输出 `[no test files]`。这是当前交付环境的检查版本，不是对生产项目最低或最新 Go 版本的推荐。

执行 `python3 verify_examples.py`，检查示例 JSON 语法、动作别名的先定义后使用、步骤 ID 唯一性、计划长度、请求 Epoch 与示例结果顺序。

没有运行 macOS/Windows 原生代码、桌面 acceptance、真实应用兼容性验证、性能或 token 基准。SPEC.md 中的预算和平台基线是待验证的工程建议。

## 阅读顺序

先读 RFC 第 0、3–10 节确定核心契约，再读第 11–19 节实现接口和两端 backend，按第 20–24 节执行 MVP/POC/验收。

原始技术来源集中在 Appendix A；实现前未决项位于 Appendix B。上层 Agent、Bot、Wails 与 renderer 的边界在第 6、17、19 节。
