module example.invalid/desktopworld

go 1.23.0
